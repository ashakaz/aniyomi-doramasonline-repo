version = 1
cloudflareBypass = false

apply<com.lagradost.cloudstream3.gradle.AnimeExtensionPlugin>()

animeExtension {
    name = "DoramasOnline"
    lang = "pt"
    className = "DoramasOnline"
}