package eu.kanade.tachiyomi.animeextension.pt.doramasonline

import eu.kanade.tachiyomi.animesource.AnimeHttpSource
import eu.kanade.tachiyomi.animesource.model.*
import okhttp3.Request
import okhttp3.Response

class DoramasOnline : AnimeHttpSource() {
    override val name = "DoramasOnline"
    override val baseUrl = "https://doramasonline.org"
    override val lang = "pt-BR"
    override val supportsLatest = false

    override fun popularAnimeRequest(page: Int): Request = GET("$baseUrl/dublados/page/$page", headers)
    override fun popularAnimeParse(response: Response): AnimesPage = AnimesPage(emptyList(), false)

    override fun episodeListParse(response: Response) = emptyList<SEpisode>()
    override fun videoListParse(response: Response) = emptyList<Video>()

    override fun searchAnimeRequest(page: Int, query: String): Request = GET("$baseUrl/?s=$query", headers)

    override fun latestUpdatesRequest(page: Int): Request = GET("$baseUrl/legendados/page/$page", headers)
    override fun latestUpdatesParse(response: Response): AnimesPage = AnimesPage(emptyList(), false)

    override fun animeDetailsParse(response: Response): SAnime = SAnime.create()
    override fun videoListRequest(episode: SEpisode): Request = GET(episode.url, headers)
}